<?php

class Database
{
    private $host = "localhost"; 
    private $user = "matlabes_nrz"; 
    private $pass = "asdf137865"; 
    private $db = "matlabes_nrz"; 
    private $conn;

    public function __construct()
    {
        $this->conn = new PDO("mysql:host=" . $this->host . ";dbname=" . $this->db, $this->user, $this->pass);
        $this->conn->exec("set names utf8");

    }
    public function showData($page = '1', $limit = '10',$group_a ='1',$group_b ='1') 
    {
        $offset = ($page - 1) * $limit;
        $sql = "SELECT * FROM phone WHERE group_b = $group_b AND group_a = $group_a ORDER BY RAND() LIMIT $limit  ";
        $q = $this->conn->query($sql) or die("failed!");
        if(isset($q)){
                while ($r = $q->fetch(PDO::FETCH_ASSOC)) { 
            $data[] = $r;
        }
return $data;
      
        }
        else 
         echo 'nodata';

        
    }
}
?>