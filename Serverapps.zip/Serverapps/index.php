<?php

require_once 'Database.php'; 

$db = new Database(); 

if (isset($_GET['page'])) { 
    $page = $_GET['page']; 
} else {
    $page = 1;
}
if (isset($_GET['group_a'])) { 
$group_a = $_GET['group_a'];
 
    

} else {
    
}
if (isset($_GET['group_b'])) { 
    $group_b = $_GET['group_b']; 
} else {
    
}

if(isset($_GET['limit'])){
    echo(json_encode($db->showData($page, $_GET['limit'] , $group_a ,$group_b)));
}