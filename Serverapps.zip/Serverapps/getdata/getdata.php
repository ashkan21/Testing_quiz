<?php

$pdo = new PDO('mysql:dbname=matlabes_nrz;host=localhost', 'matlabes_nrz', 'asdf137865');

$pdo->exec("set names utf8");



    $title = $_POST['title'];    
   $selecta = $_POST['selecta'];
 $selectb = $_POST['selectb'];
 $selectc = $_POST['selectc'];
 $selectd = $_POST['selectd'];
 $true = $_POST['true'];
 $book = $_POST['book'];
 $cat = $_POST['cat'];


  
$sql = " INSERT INTO phone ( title ,  group_a , group_b , select_a ,select_b ,select_c , select_d , true_select )
VALUES ( ' $title ' , ' $cat ' , '$book ' , '$selecta ' , '$selectb ' , '$selectc ' , '$selectd ','$true' ) " ;
$stmt = $pdo->query($sql);
if (!isset($stmt))
{
echo "اطلاعات ذخیره نشد مشکلی رخ داده است";
}else{
echo "اضافه شد";
}

  $pdo = null;       

?>